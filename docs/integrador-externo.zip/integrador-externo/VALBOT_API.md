# VALBOT API — Guia de Integração

Documentação para envio de exames práticos DETRAN à plataforma Valbot.

- **Endpoint único:** `POST https://valbot.com.br/api/exams/init-upload`
- **Autenticação:** header `X-API-Key`
- **Suporte:** lbigor@icloud.com

---

## 1. Autenticação

Toda requisição deve incluir o header:

```http
X-API-Key: vbk_live_<sua_key>
```

A key é fornecida pela equipe Valbot e não expira (revogável a pedido).

| Cenário | HTTP |
|---|---|
| Header ausente | `401 X-API-Key header obrigatório` |
| Key inválida ou revogada | `401 API key inválida, revogada ou sem scope` |
| Key OK | `200` + payload de resposta |

A cada chamada bem-sucedida o servidor atualiza `last_used_at` da key (auditoria).

---

## 2. Endpoint

### `POST /api/exams/init-upload`

Registra um novo exame no sistema e devolve uma URL assinada (`signed_url`) onde o vídeo deve ser enviado via `PUT` direto pro Google Cloud Storage. O vídeo **não passa pelo servidor Valbot** — sobe direto pra `storage.googleapis.com`.

**Headers:**

| Header | Valor |
|---|---|
| `X-API-Key` | `vbk_live_...` (obrigatório) |
| `Content-Type` | `application/json` (obrigatório) |

**Body (JSON):**

| Campo | Tipo | Obrigatório | Aceita |
|---|---|---|---|
| `filename` | string | sim | nome do arquivo com extensão `.mp4`, `.mov`, `.m4v` (ex: `"exame-2026-001.mp4"`) |
| `size_bytes` | int | sim | tamanho do vídeo em bytes. **Máximo: 600 MB** (`629145600`) |
| `content_type` | string | sim | um dos: `"video/mp4"`, `"video/quicktime"`, `"video/x-m4v"` |
| `renach` | string | sim | RENACH/CNH do candidato (qualquer formato — texto livre até 50 chars) |
| `candidato_nome` | string | sim | nome completo, até 200 chars |
| `candidato_cpf` | string | sim | CPF do candidato (com ou sem formatação, até 20 chars) |
| `processo` | string | sim | nº do processo DETRAN (até 50 chars) |
| `categoria` | string | sim | uma de: `"A"`, `"B"`, `"AB"`, `"C"`, `"D"`, `"E"` |
| `veiculo` | string | sim | modelo + placa (ex: `"VW Gol ABC1D23"`, até 100 chars) |
| `local` | string | sim | unidade DETRAN ou CFC onde o exame ocorreu (até 100 chars) |
| `examinador` | string | sim | nome do examinador, até 200 chars |
| `auto_escola` | string | sim | nome do CFC, até 200 chars |
| `rubrica` | string | sim | regulamento aplicado. Use `"1020/2025"` (Resolução CONTRAN vigente) |
| `training_annotations` | string | não | JSON livre com anotações pra treino do modelo. Pode mandar `""` |
| `sha256_client` | string | não | SHA-256 hex do vídeo (recomendado — habilita cache e dedupe) |

**Resposta `200`:**

```json
{
  "analysis_id": "5d4a28262e0644409509be84666bc330",
  "signed_url": "https://storage.googleapis.com/valbot-prod/uploads/5d4a.../video.mp4?X-Goog-Algorithm=...&X-Goog-Signature=...",
  "gs_path": "gs://valbot-prod/uploads/5d4a.../video.mp4",
  "expires_in_minutes": 20,
  "expected_content_type": "video/mp4"
}
```

| Campo | Descrição |
|---|---|
| `analysis_id` | identificador único da análise (32 chars hex). Guarde — é a referência do exame. |
| `signed_url` | URL temporária pra `PUT` do vídeo. Expira em 20 minutos. |
| `gs_path` | caminho final no GCS (`gs://...`). Não precisa usar — só pra log. |
| `expires_in_minutes` | TTL da `signed_url`. Após isso, gere novo init-upload. |
| `expected_content_type` | `Content-Type` que o `PUT` deve usar. **Tem que bater** com o do header. |

**Erros:**

| HTTP | Quando | Body |
|---|---|---|
| `401` | header `X-API-Key` ausente ou inválido | `{"detail": "X-API-Key header obrigatório"}` |
| `415` | `content_type` não suportado | `{"detail": "content_type 'X' não suportado"}` |
| `422` | body inválido (campo faltando, tipo errado) | `{"detail": [...]}` |
| `503` | infra indisponível (GCS, IAM) | `{"detail": "Não foi possível gerar signed URL: ..."}` |

---

## 3. Como enviar o vídeo

Após receber a `signed_url`, faça `PUT` direto pro GCS com o arquivo de vídeo no body. Sem header de auth — a assinatura está embutida na URL.

```bash
curl -X PUT "<signed_url>" \
  -H "Content-Type: video/mp4" \
  --data-binary @exame-2026-001.mp4
```

O `Content-Type` do `PUT` precisa ser **exatamente** o `expected_content_type` retornado no init-upload — senão GCS rejeita.

Resposta esperada: `200 OK` (sem body). Vídeo está armazenado.

---

## 4. Exemplo completo (curl)

```bash
# 1) Registra o exame e pega a signed_url
RESP=$(curl -sX POST https://valbot.com.br/api/exams/init-upload \
  -H "X-API-Key: vbk_live_SUA_KEY_AQUI" \
  -H "Content-Type: application/json" \
  -d '{
    "filename": "exame-2026-001.mp4",
    "size_bytes": 52428800,
    "content_type": "video/mp4",
    "renach": "SP-12345678",
    "candidato_nome": "Joao Silva",
    "candidato_cpf": "12345678901",
    "processo": "PROC-2026-001",
    "categoria": "B",
    "veiculo": "VW Gol ABC1D23",
    "local": "DETRAN Centro - SP",
    "examinador": "Maria Souza",
    "auto_escola": "CFC Estrela",
    "rubrica": "1020/2025",
    "training_annotations": ""
  }')

echo "$RESP" | jq .

# 2) Extrai signed_url e faz upload do vídeo
SIGNED_URL=$(echo "$RESP" | jq -r .signed_url)
curl -X PUT "$SIGNED_URL" \
  -H "Content-Type: video/mp4" \
  --data-binary @exame-2026-001.mp4
```

---

## 5. Exemplo (Python)

```python
import requests

API_KEY = "vbk_live_SUA_KEY_AQUI"
VIDEO_PATH = "exame-2026-001.mp4"

import os
size = os.path.getsize(VIDEO_PATH)

# 1) init-upload
r = requests.post(
    "https://valbot.com.br/api/exams/init-upload",
    headers={"X-API-Key": API_KEY, "Content-Type": "application/json"},
    json={
        "filename": "exame-2026-001.mp4",
        "size_bytes": size,
        "content_type": "video/mp4",
        "renach": "SP-12345678",
        "candidato_nome": "Joao Silva",
        "candidato_cpf": "12345678901",
        "processo": "PROC-2026-001",
        "categoria": "B",
        "veiculo": "VW Gol ABC1D23",
        "local": "DETRAN Centro - SP",
        "examinador": "Maria Souza",
        "auto_escola": "CFC Estrela",
        "rubrica": "1020/2025",
        "training_annotations": "",
    },
)
r.raise_for_status()
data = r.json()
print("analysis_id:", data["analysis_id"])

# 2) PUT do vídeo no GCS
with open(VIDEO_PATH, "rb") as f:
    up = requests.put(
        data["signed_url"],
        headers={"Content-Type": data["expected_content_type"]},
        data=f,
    )
up.raise_for_status()
print("upload OK")
```

---

## 6. Exemplo (Node.js)

```javascript
const fs = require("fs");

const API_KEY = "vbk_live_SUA_KEY_AQUI";
const VIDEO_PATH = "exame-2026-001.mp4";

const stat = fs.statSync(VIDEO_PATH);

// 1) init-upload
const r = await fetch("https://valbot.com.br/api/exams/init-upload", {
  method: "POST",
  headers: {
    "X-API-Key": API_KEY,
    "Content-Type": "application/json",
  },
  body: JSON.stringify({
    filename: "exame-2026-001.mp4",
    size_bytes: stat.size,
    content_type: "video/mp4",
    renach: "SP-12345678",
    candidato_nome: "Joao Silva",
    candidato_cpf: "12345678901",
    processo: "PROC-2026-001",
    categoria: "B",
    veiculo: "VW Gol ABC1D23",
    local: "DETRAN Centro - SP",
    examinador: "Maria Souza",
    auto_escola: "CFC Estrela",
    rubrica: "1020/2025",
    training_annotations: "",
  }),
});
const data = await r.json();
console.log("analysis_id:", data.analysis_id);

// 2) PUT do vídeo no GCS
const up = await fetch(data.signed_url, {
  method: "PUT",
  headers: { "Content-Type": data.expected_content_type },
  body: fs.createReadStream(VIDEO_PATH),
  duplex: "half",
});
console.log("upload status:", up.status);
```

---

## 7. Boas práticas

- **Idempotência**: cada chamada gera um novo `analysis_id` (UUID). Não há dedupe automático — controle no seu lado se necessário (use `sha256_client`).
- **Retry**: se `init-upload` retornar `503`, retente após alguns segundos. Se o `PUT` no GCS falhar, gere novo `init-upload` (a `signed_url` antiga pode ter expirado).
- **TTL da URL**: 20 minutos. Se vai demorar mais, gere o init-upload **logo antes** do `PUT`.
- **Tamanho**: vídeos acima de 600 MB serão rejeitados. Reduza a duração ou compactação antes do envio.
- **Rate limit**: ainda não há limite explícito, mas evite mais de ~10 init-upload/segundo. Avise se precisar de throughput maior.
- **Revogação**: se a key vazar, avise lbigor@icloud.com — revogamos imediatamente e geramos nova.

---

## 8. O que acontece depois?

1. Vídeo entra no Google Cloud Storage.
2. Pipeline Valbot baixa, processa com VLM (Vertex AI Gemini), aplica rubrica `1020/2025`.
3. Laudo gerado em formato JSON + PDF, disponível na interface interna do Valbot.
4. RENACH é o identificador de busca — mesmo candidato pode ter múltiplos exames.

O agente externo **não consulta status** nem **baixa resultado** via API — esses fluxos são internos. Se precisar saber se o exame foi processado, consulte a equipe Valbot.

---

## 9. URL de referência

```
POST https://valbot.com.br/api/exams/init-upload
```

Ambiente único (produção). Sem staging exposto publicamente.
